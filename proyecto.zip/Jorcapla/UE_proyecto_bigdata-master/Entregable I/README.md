### Este entregable contiene 
- docker-compose.yml con los contenedores de la plataforma smart basada en Fiware para crear entidades y persistir los datos en MongoDb
- Colleccion de postman para realizar crear entidades, crear suscripciones y actualizar datos de las entidades
