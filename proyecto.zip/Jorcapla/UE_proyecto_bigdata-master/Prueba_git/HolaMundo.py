# Autor: Jorge Capel
# Descripcion : Ejemplo de programa python para imprimir hola mundo en pantalla
def sumar(a,b):
    return a +b 
resultado = sumar(5,6)
print(resultado)
def imprimir(texto):
  print(texto);
imprimir("Hola Mundo");
